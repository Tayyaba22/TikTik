import 'package:flutter/material.dart';

import 'clock_text.dart';

class ClockFace extends StatelessWidget{

  final DateTime dateTime;
  final ClockText clockText;
  ClockFace({this.clockText = ClockText.arabic, this.dateTime});

  @override
  Widget build(BuildContext context) {
    return Center(
          child: new Padding(
        padding: const EdgeInsets.all(10.0),
        child: new AspectRatio(
          aspectRatio: 0.75,
          child: new Container(
            width: double.infinity,
            decoration: new BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0xFFfff9fd),
              boxShadow: [
                BoxShadow
                (
                  offset: Offset(0, 0),
                  blurRadius: 5,
                  spreadRadius: 20,
                  color: Color(0xffe1bee7)
                )
              ]
            ),
          ),

        ),
      ),
    );
  }
}


